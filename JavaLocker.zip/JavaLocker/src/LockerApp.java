// without number pad
//import java.awt.*;
//import java.awt.event.*;
//import javax.swing.*;
//
//public class LockerApp extends JFrame {
//    private JLabel mssLabel;
//    private JPasswordField passcode;
//    private String savedPasscode;
//    private JButton enterBtn;
//    private void form() {
//        passcode = new JPasswordField(15);
//        enterBtn = new JButton("Enter");
//        mssLabel = new JLabel("");
//        JPanel panel = new JPanel(new FlowLayout());
//        panel.add(new JLabel("Passcode: "));
//        panel.add(passcode);
//        panel.add(enterBtn);
//        panel.add(mssLabel);
//        this.getContentPane().add(panel);
//        enterBtn.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                String userEnterPasscode = new String(passcode.getPassword());
//                confirmPasscode(userEnterPasscode);
//            }
//        });
//        this.setSize(600, 80);
//        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        this.setVisible(true);
//    }
//    private void confirmPasscode(String enteredPasscode) {
//        if (savedPasscode == null) {
//             int choice = JOptionPane.showConfirmDialog(this, "None passcode is set.", "Set Passcode", JOptionPane.YES_NO_OPTION);
//            if (choice == JOptionPane.YES_OPTION) {
//                setPasscode();
//            }
//        } else if (savedPasscode.equals(enteredPasscode)) {
//            mssLabel.setText("Correct Passcode");
//              JOptionPane.showMessageDialog(this, "open the locker", "Success", JOptionPane.INFORMATION_MESSAGE);
//              clearPasscode();
//        } else {
//            mssLabel.setText("Incorrect Passcode");
//        }
//    }
//    private void setPasscode() {
//        String newPasscode = JOptionPane.showInputDialog(this, "Enter your passcode:", "Set passcode");
//        if (newPasscode != null && !newPasscode.isEmpty()) {
//            savedPasscode = newPasscode;
//            mssLabel.setText("Passcode set successful.");
//        } else {
//             mssLabel.setText("Passcode can't empty.");
//        }
//        clearPasscode();
//    }
//    private void clearPasscode() {
//        passcode.setText("");
//    }
//    public static void main(String[] args) {
//        new LockerApp();
//    }
//    public LockerApp() {
//        super("Locker");
//        form();
//    }
//}


// with number pad
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LockerApp extends JFrame {
    private JLabel mssLabel;
    private JPasswordField passcode;
    private String savedPasscode;
    private JButton enterBtn;
    private JButton clearBtn;
    private JButton[] numBtns;

    public LockerApp() {
        super("Locker");
        form();
    }

    private void form() {
        passcode = new JPasswordField(15);
        enterBtn = new JButton("Enter");
        clearBtn = new JButton("Clear");
        mssLabel = new JLabel("");

        JPanel panel = new JPanel(new FlowLayout());
        panel.add(new JLabel("Passcode: "));
        panel.add(passcode);

        JPanel buttonPanel = new JPanel(new GridLayout(4, 3, 5, 5));
        numBtns = new JButton[10];

        for (int i = 0; i < 10; i++) {
            numBtns[i] = new JButton(String.valueOf(i));
            numBtns[i].addActionListener(new NumberButtonListener());
            buttonPanel.add(numBtns[i]);
        }

        buttonPanel.add(clearBtn);
        buttonPanel.add(enterBtn);
        buttonPanel.add(mssLabel);

        panel.add(buttonPanel);
        this.getContentPane().add(panel);

        enterBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userEnterPasscode = new String(passcode.getPassword());
                confirmPasscode(userEnterPasscode);
            }
        });

        clearBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearPasscode();
            }
        });

        this.setSize(700, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    private void confirmPasscode(String enteredPasscode) {
        if (savedPasscode == null) {
            int choice = JOptionPane.showConfirmDialog(this, "None passcode is set.", "Set Passcode", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
                setPasscode();
            }
        } else if (savedPasscode.equals(enteredPasscode)) {
            mssLabel.setText("Correct Passcode");
            JOptionPane.showMessageDialog(this, "LOcker is opening", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearPasscode();
        } else {
            mssLabel.setText("Incorrect Passcode");
        }
    }

    private void setPasscode() {
        String newPasscode = JOptionPane.showInputDialog(this, "Enter your passcode:", "Set ur passcode");
        if (newPasscode != null && !newPasscode.isEmpty()) {
            savedPasscode = newPasscode;
            mssLabel.setText("Passcode set.");
        } else {
            mssLabel.setText("Passcode can't empty.");
        }
        clearPasscode();
    }

    private void clearPasscode() {
        passcode.setText("");
    }

    private class NumberButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            passcode.setText(passcode.getText() + command);
        }
    }

    public static void main(String[] args) {
        new LockerApp();
    }
}
